{{- define "api.fullname" -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "api.selectorLabels" -}}
{{ include "saas-platform.selectorLabels" . }}
{{- end }}

{{- define "api.labels" -}}
{{ include "saas-platform.labels" . }}
{{- with .Values.additionalLabels }}
{{ toYaml . | trim }}
{{- end }}
{{- end }}

{{- define "api.annotations" -}}
checksum/config: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
checksum/secrets: {{ include (print $.Template.BasePath "/secrets.yaml") . | sha256sum }}
{{- with .Values.additionalAnnotations }}
{{ toYaml . | trim }}
{{- end }}
{{- end }}

{{- define "api.image" -}}
{{- $registry := .Values.image.registry | default .Values.global.repository -}}
{{- $name := .Values.image.name | default .Chart.Name -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry }}
{{- printf "%s/%s:%s" $registry $name $tag }}
{{- else }}
{{- printf "%s:%s" $name $tag }}
{{- end }}
{{- end }}

{{- define "api.troubleshootingContainer" -}}
- name: shell
  image: busybox:1.28
  command: ["sleep", "3600"]
  securityContext:
    capabilities:
      add:
        - SYS_PTRACE
  stdin: true
  tty: true
{{- end }}

{{/*
Probes render only when their values block is present, so any probe can be
disabled by removing (or nulling) it. httpGet/tcpSocket ports default to
service.port.
*/}}
{{- define "api.probes" -}}
{{- with .Values.livenessProbe }}
livenessProbe:
  {{- include "api.probeSpec" (dict "probe" . "root" $) | trim | nindent 2 }}
{{- end }}
{{- with .Values.readinessProbe }}
readinessProbe:
  {{- include "api.probeSpec" (dict "probe" . "root" $) | trim | nindent 2 }}
{{- end }}
{{- with .Values.startupProbe }}
startupProbe:
  {{- include "api.probeSpec" (dict "probe" . "root" $) | trim | nindent 2 }}
{{- end }}
{{- end }}

{{- define "api.probeSpec" -}}
{{- $probe := .probe }}
{{- $defaultPort := "" }}
{{- with .root.Values.service }}
{{- $defaultPort = .port }}
{{- end }}
{{- with $probe.httpGet }}
httpGet:
  path: {{ .path }}
  port: {{ .port | default $defaultPort }}
{{- end }}
{{- if hasKey $probe "tcpSocket" }}
tcpSocket:
  port: {{ $probe.tcpSocket.port | default $defaultPort }}
{{- end }}
{{- if hasKey $probe "grpc" }}
grpc:
  port: {{ $probe.grpc.port | default $defaultPort }}
{{- end }}
{{- with $probe.exec }}
exec:
  command: {{ toJson .command }}
{{- end }}
{{- range $field := list "initialDelaySeconds" "periodSeconds" "timeoutSeconds" "successThreshold" "failureThreshold" "terminationGracePeriodSeconds" }}
{{- if hasKey $probe $field }}
{{ $field }}: {{ index $probe $field }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Volume helpers share one values schema across all workload kinds:

  volumes:
    - name: app-config
      mountPath: /etc/app/config
      configMap: app-configmap        # or: secret, existingClaim, hostPath, emptyDir
    - name: data                      # statefulset only: becomes a volumeClaimTemplate
      mountPath: /data
      pvc:
        accessModes: ["ReadWriteOnce"]
        resources: { requests: { storage: 1Gi } }
*/}}
{{- define "api.volumeMounts" -}}
{{- range .Values.volumes }}
- name: {{ .name }}
  mountPath: {{ .mountPath }}
  {{- with .subPath }}
  subPath: {{ . }}
  {{- end }}
  readOnly: {{ .readOnly | default false }}
{{- end }}
{{- end }}

{{- define "api.volumes" -}}
{{- range .Values.volumes }}
{{- if .configMap }}
- name: {{ .name }}
  configMap:
    name: {{ .configMap }}
{{- else if .secret }}
- name: {{ .name }}
  secret:
    secretName: {{ .secret }}
{{- else if .existingClaim }}
- name: {{ .name }}
  persistentVolumeClaim:
    claimName: {{ .existingClaim }}
{{- else if .hostPath }}
- name: {{ .name }}
  hostPath:
    path: {{ .hostPath }}
{{- else if hasKey . "emptyDir" }}
- name: {{ .name }}
  emptyDir: {}
{{- else if not .pvc }}
{{- fail (printf "volume %q must set one of: configMap, secret, existingClaim, hostPath, emptyDir, pvc" .name) }}
{{- end }}
{{- end }}
{{- end }}

{{- define "api.volumeClaimTemplates" -}}
{{- range .Values.volumes }}
{{- if .pvc }}
- metadata:
    name: {{ .name }}
  spec:
    accessModes:
      {{- toYaml .pvc.accessModes | nindent 6 }}
    {{- with .pvc.storageClassName }}
    storageClassName: {{ . }}
    {{- end }}
    resources:
      requests:
        storage: {{ .pvc.resources.requests.storage }}
{{- end }}
{{- end }}
{{- end }}

{{- define "saas-platform.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Headless Service name for a StatefulSet. Truncates to 63 chars AFTER appending
the -headless suffix (the fullname helper truncates before it), so a near-limit
fullname can't produce an invalid DNS label. Used by both the headless Service
and the StatefulSet's serviceName so the two always agree.
*/}}
{{- define "saas-platform.headlessName" -}}
{{- printf "%s-headless" (include (print .Chart.Name ".fullname") .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels: the immutable identity of a workload. Keep this pair stable —
it is used by Deployment/StatefulSet/DaemonSet selectors, Services,
NetworkPolicies, and PodDisruptionBudgets.
*/}}
{{- define "saas-platform.selectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "saas-platform.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "saas-platform.selectorLabels" . }}
{{- with .Chart.AppVersion }}
app.kubernetes.io/version: {{ . | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Shared pod template used by every workload kind. Per-chart helpers
(<chart>.labels, <chart>.annotations, <chart>.probes, <chart>.volumes, ...)
are resolved dynamically so each subchart keeps its own identity.
*/}}
{{- define "saas-platform.podTemplate" -}}
metadata:
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
    {{- with .Values.podAnnotations }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  {{- include "saas-platform.podSpec" . | trim | nindent 2 }}
{{- end }}

{{- define "saas-platform.podSpec" -}}
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.serviceAccountName }}
serviceAccountName: {{ . }}
{{- end }}
{{- with .Values.terminationGracePeriodSeconds }}
terminationGracePeriodSeconds: {{ . }}
{{- end }}
{{- if .Values.troubleshootingContainer }}
shareProcessNamespace: true
{{- end }}
{{- with .Values.podSecurityContext }}
securityContext:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.initContainers }}
initContainers:
  {{- toYaml . | nindent 2 }}
{{- end }}
containers:
  {{- include "saas-platform.containers" . | trim | nindent 2 }}
{{- with .Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- $podVolumes := include (print .Chart.Name ".volumes") . | trim }}
{{- if $podVolumes }}
volumes:
  {{- $podVolumes | nindent 2 }}
{{- end }}
{{- end }}

{{- define "saas-platform.containers" -}}
{{- if .Values.troubleshootingContainer }}
{{- include (print .Chart.Name ".troubleshootingContainer") . }}
{{- end }}
- name: {{ .Chart.Name }}
  image: {{ include (print .Chart.Name ".image") . }}
  imagePullPolicy: {{ .Values.image.pullPolicy | default "IfNotPresent" }}
  {{- with .Values.command }}
  command:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.args }}
  args:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if .Values.service }}
  ports:
    - name: {{ .Values.service.portName | default "http" }}
      containerPort: {{ .Values.service.targetPort | default .Values.service.port }}
      protocol: TCP
  {{- end }}
  {{- with .Values.securityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- $probes := include (print .Chart.Name ".probes") . | trim }}
  {{- if $probes }}
  {{- $probes | nindent 2 }}
  {{- end }}
  {{- with .Values.lifecycle }}
  lifecycle:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if or .Values.config .Values.secrets .Values.envFrom }}
  envFrom:
    {{- if .Values.config }}
    - configMapRef:
        name: {{ include (print .Chart.Name ".fullname") . }}
    {{- end }}
    {{- if .Values.secrets }}
    - secretRef:
        name: {{ include (print .Chart.Name ".fullname") . }}
    {{- end }}
    {{- with .Values.envFrom }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- end }}
  {{- with .Values.env }}
  env:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- $mounts := include (print .Chart.Name ".volumeMounts") . | trim }}
  {{- if $mounts }}
  volumeMounts:
    {{- $mounts | nindent 4 }}
  {{- end }}
{{- end }}

{{- define "saas-platform.daemonset" -}}
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: {{ include (print .Chart.Name ".fullname") . }}
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
spec:
  {{- with .Values.updateStrategy }}
  updateStrategy:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
      {{- include (print .Chart.Name ".selectorLabels") . | nindent 6 }}
  template:
    {{- include "saas-platform.podTemplate" . | nindent 4 }}
{{- end }}

{{- define "saas-platform.deployment" -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include (print .Chart.Name ".fullname") . }}
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
spec:
  {{- if eq .Values.podCount.type "static" }}
  replicas: {{ .Values.podCount.static }}
  {{- end }}
  {{- with .Values.strategy }}
  strategy:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
      {{- include (print .Chart.Name ".selectorLabels") . | nindent 6 }}
  template:
    {{- include "saas-platform.podTemplate" . | nindent 4 }}
{{- end }}

{{- define "saas-platform.hpa" -}}
{{- if eq .Values.podCount.type "dynamic" }}
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ include (print .Chart.Name ".fullname") . }}
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    # workloadKind is set by chartpress to match the subchart's workload.
    kind: {{ .Values.workloadKind | default "Deployment" }}
    name: {{ include (print .Chart.Name ".fullname") . }}
  minReplicas: {{ .Values.podCount.dynamic.minReplicas }}
  maxReplicas: {{ .Values.podCount.dynamic.maxReplicas }}
  metrics:
    {{- with .Values.podCount.dynamic.metrics }}
      {{- toYaml . | nindent 4 }}
    {{- else }}
      {{- with .Values.podCount.dynamic.targetMemoryUtilizationPercentage }}
      - type: Resource
        resource:
          name: memory
          target:
            type: Utilization
            averageUtilization: {{ . }}
      {{- end }}
      {{- with .Values.podCount.dynamic.targetCPUUtilizationPercentage }}
      - type: Resource
        resource:
          name: cpu
          target:
            type: Utilization
            averageUtilization: {{ . }}
      {{- end }}
    {{- end }}
  {{- with .Values.podCount.dynamic.behavior }}
  behavior:
    {{- toYaml . | nindent 4 }}
  {{- end }}
{{- end }}
{{- end }}

{{- define "saas-platform.networkPolicy" -}}
{{- if and .Values.networkPolicy .Values.networkPolicy.enabled }}
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: {{ include (print .Chart.Name ".fullname") . }}
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
spec:
  podSelector:
    matchLabels:
      {{- include (print .Chart.Name ".selectorLabels") . | nindent 6 }}
  policyTypes:
    - Ingress
  ingress:
    - from:
        {{- toYaml .Values.networkPolicy.ingressFrom | nindent 8 }}
{{- end }}
{{- end }}

{{- define "saas-platform.pdb" -}}
{{- if and .Values.pdb .Values.pdb.enabled }}
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ include (print .Chart.Name ".fullname") . }}
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
spec:
  {{- with .Values.pdb.minAvailable }}
  minAvailable: {{ . }}
  {{- end }}
  {{- with .Values.pdb.maxUnavailable }}
  maxUnavailable: {{ . }}
  {{- end }}
  selector:
    matchLabels:
      {{- include (print .Chart.Name ".selectorLabels") . | nindent 6 }}
{{- end }}
{{- end }}

{{- define "saas-platform.service" -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ include (print .Chart.Name ".fullname") . }}
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
spec:
  type: {{ .Values.service.type | default "ClusterIP" }}
  ports:
    - name: {{ .Values.service.portName | default "http" }}
      port: {{ .Values.service.port }}
      targetPort: {{ .Values.service.targetPort | default .Values.service.port }}
      protocol: TCP
      {{- with .Values.service.appProtocol }}
      appProtocol: {{ . }}
      {{- end }}
  selector:
    {{- include (print .Chart.Name ".selectorLabels") . | nindent 4 }}
{{- end }}

{{/*
Headless service backing a StatefulSet's serviceName. Emitted via
templates/headless-service.yaml, which chartpress adds to statefulset
subcharts.
*/}}
{{- define "saas-platform.headlessService" -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ include "saas-platform.headlessName" . }}
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
spec:
  clusterIP: None
  publishNotReadyAddresses: true
  {{- if .Values.service }}
  ports:
    - name: {{ .Values.service.portName | default "http" }}
      port: {{ .Values.service.port }}
      targetPort: {{ .Values.service.targetPort | default .Values.service.port }}
      protocol: TCP
  {{- end }}
  selector:
    {{- include (print .Chart.Name ".selectorLabels") . | nindent 4 }}
{{- end }}

{{- define "saas-platform.statefulset" -}}
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: {{ include (print .Chart.Name ".fullname") . }}
  labels:
    {{- include (print .Chart.Name ".labels") . | nindent 4 }}
  annotations:
    {{- include (print .Chart.Name ".annotations") . | nindent 4 }}
spec:
  serviceName: {{ include "saas-platform.headlessName" . }}
  {{- if eq .Values.podCount.type "static" }}
  replicas: {{ .Values.podCount.static }}
  {{- end }}
  {{- with .Values.podManagementPolicy }}
  podManagementPolicy: {{ . }}
  {{- end }}
  {{- with .Values.updateStrategy }}
  updateStrategy:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
      {{- include (print .Chart.Name ".selectorLabels") . | nindent 6 }}
  template:
    {{- include "saas-platform.podTemplate" . | nindent 4 }}
  {{- $claims := include (print .Chart.Name ".volumeClaimTemplates") . | trim }}
  {{- if $claims }}
  volumeClaimTemplates:
    {{- $claims | nindent 4 }}
  {{- end }}
{{- end }}

