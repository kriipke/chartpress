# HANDOFF — finish this chart against the application code

This file is addressed to the coding agent (or developer) who has this chart
**and** the application source code side by side. chartpress generated the
first half of this chart; your job is the second half: resolve every
app-specific placeholder against the real code.

Completion is incremental: **delete a subchart's section below when that
component is finished; delete this file when the chart is done** — its
absence is the "chart is finished" signal.

## Ground rules

1. **The best practices are load-bearing.** They are documented in
   [docs/best-practices.adoc](docs/best-practices.adoc) — read it before
   editing. Placeholders are **replaced, never deleted**; disabled practices
   (PDB, NetworkPolicy, securityContext) are **enabled, never removed**. If a
   practice truly cannot apply, record why in that subchart's README.
2. **Work from evidence, not convention.** Every answer should come from the
   application code, Dockerfile, or CI config. If the code doesn't answer a
   question (e.g. no health endpoint exists), the fix may belong in the app.
3. **Don't restructure.** Keep selector labels, helper names, the values
   schema, and the file layout as generated. Never change `selectorLabels`;
   never set `replicas` alongside an HPA.
4. **Validate every change**: `make template`, `make lint`, `make test`
   (render + kubeconform) from the chart root.
5. Don't add subcharts for databases, caches, or brokers — those belong in
   `Chart.yaml` `dependencies:` as upstream charts. Sidecars are containers
   in the owning pod, never new subcharts.

## Platform

- Values layering: a subchart's own `values.yaml` holds its defaults; the
  umbrella `values.yaml` overrides them under the subchart's name; shared
  settings live under `global:`.
- [ ] Set `global.repository` and pin every image tag
  (`grep -rn "TODO(chartpress)" .` is the authoritative list).

## charts/api — API microservice

Generated as `api-microservice` (deployment · http :8080 · ingress · auto).

- [ ] Find the port the app actually listens on (code or Dockerfile EXPOSE) and set service.port.
- [ ] Find or add the real liveness and readiness endpoints; decide whether readiness should check dependencies.
- [ ] Map required env vars: which come from shared config, which need this chart's own Secret.
- [ ] Measure or estimate request drain time on shutdown and set terminationGracePeriodSeconds from it.
- [ ] Size resources requests and the memory limit from observed or expected load.

## charts/job-runner — API microservice

Generated as `api-microservice` (deployment · http :8080 · ingress · auto).

- [ ] Find the port the app actually listens on (code or Dockerfile EXPOSE) and set service.port.
- [ ] Find or add the real liveness and readiness endpoints; decide whether readiness should check dependencies.
- [ ] Map required env vars: which come from shared config, which need this chart's own Secret.
- [ ] Measure or estimate request drain time on shutdown and set terminationGracePeriodSeconds from it.
- [ ] Size resources requests and the memory limit from observed or expected load.

## charts/database — API microservice

Generated as `api-microservice` (statefulset · http :8080 · ingress · auto). Explicit overrides: workload.

- [ ] Find the port the app actually listens on (code or Dockerfile EXPOSE) and set service.port.
- [ ] Find or add the real liveness and readiness endpoints; decide whether readiness should check dependencies.
- [ ] Map required env vars: which come from shared config, which need this chart's own Secret.
- [ ] Measure or estimate request drain time on shutdown and set terminationGracePeriodSeconds from it.
- [ ] Size resources requests and the memory limit from observed or expected load.

## Done means

- `grep -rn "TODO(chartpress)" .` returns nothing.
- `make test` passes.
- Every section above is resolved and deleted, and this file with them.
